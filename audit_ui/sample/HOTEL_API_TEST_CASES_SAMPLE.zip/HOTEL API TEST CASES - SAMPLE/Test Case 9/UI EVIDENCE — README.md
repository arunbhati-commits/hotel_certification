# TC 9 — Cancellation policy displayed in our app

The cancellation policy returned by Tripjack's /hms/v3/hotel/review
endpoint (see `TJ test Hotel review Response.json` -> `option.cancellation`)
is rendered on our Booking Detail page at:

  - `/app/frontend/src/pages/BookingDetailPage.js`
  - Block: 'Cancellation Policy' (refundable / non-refundable + per-window rules)

A screenshot of the rendered UI is provided in `UI_evidence_cancellation_policy.png`
in the same folder. Sample policy values from this live run:

  refundable      = True
  policy entries  = 0
  hotel id (hid)  = 100000000994
  option id       = a85efd38-e3a1-4b66-80c4-aef08bff8fab
